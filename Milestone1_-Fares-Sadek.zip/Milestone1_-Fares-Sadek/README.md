# Milestone1_
purpose of this project is to create a website dedicated to showcasing the iconic automobile manufacturer, Porsche.
The website will serve as an immersive platform for Porsche enthusiasts and potential
customers to explore the brand, its history.
info@porsche.com
The contributers to the project: Omar Ossama, Omar Elmeselhy, Donia Salem, Fares Sadek, Hussain Yasser, Mazen Yasser.
