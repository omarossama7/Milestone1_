# a) Install dependencies
npm install

# b) Run all necessary parts of the codebase
npm start
